document.addEventListener('DOMContentLoaded', function() {
    var recoveryForm = document.getElementById('recovery-form');
const emailInput = document.getElementById('email-input');
const messageDiv = document.getElementById('message');

recoveryForm.addEventListener('submit', function (e) {

  const email = emailInput.value;

  firebase.auth().sendPasswordResetEmail(email)
    .then(function () {
      messageDiv.textContent = 'Un\'email di recupero password è stata inviata al tuo indirizzo.';
      messageDiv.style.color = 'green';
    })
    .catch(function (error) {
      messageDiv.textContent = 'Si è verificato un errore durante l\'invio dell\'email di recupero password.';
      messageDiv.style.color = 'red';
      console.log(error);
    });
});
  });