function aggiungiAlCarrello() {

  const user = firebase.auth().currentUser;
  const userId = user ? user.uid : null;
  
  if (!userId) {
    alert("Devi eseguire l'accesso prima di acquistare un prodotto.");
    return;
  }
  const nome = document.getElementById("nome").textContent;
  const luogo = document.getElementById("luogo").textContent;
  const descrizione = document.getElementById("descrizione").textContent;
  const prezzo = document.getElementById("prezzo").textContent;
  const foto = document.getElementById("foto").src;
  const quantity = document.getElementById("quantity").value;
  

  const cartItem = {
    userId: userId,
    nome: nome,
    luogo: luogo,
    descrizione: descrizione,
    quantity: quantity,
    prezzo: prezzo,
      foto: foto
    };
  

    firebase.firestore().collection("carrello").add(cartItem)
      .then(function(docRef) {
        console.log("Item added to the cart with ID: ", docRef.id);
        alert("Item added to the cart successfully!");
      })
      .catch(function(error) {
        console.error("Error adding item to the cart: ", error);
        alert("An error occurred while adding the item to the cart. Please try again.");
      });
  }
  

document.getElementById("buyButton").addEventListener("click", aggiungiAlCarrello);
  