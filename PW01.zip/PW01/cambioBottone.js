firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        const myButton = document.getElementById("myButton");
        myButton.innerHTML = "Utente";
        myButton.addEventListener("click", function() {
            window.location.href = "dashboard.html";
        });
    } else {
        const myButton = document.getElementById("myButton");
        myButton.style.display = "block";
        myButton.addEventListener("click", function() {
            window.location.href = "login.html";
        });
    }
});
