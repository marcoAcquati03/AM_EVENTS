function redirectToSearch() {

    const query = document.getElementById("search").value;
    window.location.href = "cerca.html?query=" + encodeURIComponent(query);
}

function handleSearch(event) {
    if (event.key === "Enter") {
        redirectToSearch();
    }
}


document.getElementById("search").addEventListener("keyup", handleSearch);


firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        const myButton = document.getElementById("myButton");
        myButton.innerHTML = "Utente";
        myButton.addEventListener("click", function() {
            window.location.href = "dashboard.html";
        });
    } else {
        const myButton = document.getElementById("myButton");
        myButton.style.display = "block";
    }
});
