function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    const regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function search(query) {
    document.getElementById("searchResults").innerHTML = "";

 
    db.collection("eventi")
        .where("luogo", "==", query)
        .get()
        .then(function (querySnapshot) {
            querySnapshot.forEach(function (doc) {
                const resultDiv = document.createElement("div");
                const museoLink = document.createElement("a");
                museoLink.href = "javascript:void(0)";
                museoLink.onclick = function () {
                    redirectToMuseoPage(doc.id);
                };
                const nomeElement = document.createElement("h3");
                const descrizioneElement = document.createElement("p");
                const fotoElement = document.createElement("img");
                const luogoElement = document.createElement("p");
                const prezzoElement = document.createElement("p");

                nomeElement.textContent = doc.data().Nome;
                descrizioneElement.textContent = doc.data().Descrizione;
                fotoElement.src = doc.data().foto;
                luogoElement.textContent = doc.data().luogo;
                prezzoElement.textContent = "Prezzo: " + doc.data().prezzo + " €";


                museoLink.appendChild(nomeElement);
                museoLink.appendChild(descrizioneElement);
                museoLink.appendChild(fotoElement);
                museoLink.appendChild(luogoElement);
                museoLink.appendChild(prezzoElement);


                resultDiv.appendChild(museoLink);

                document.getElementById("searchResults").appendChild(resultDiv);
            });
        })
        .catch(function (error) {
            console.log("Error getting documents: ", error);
        });
}


const query = getParameterByName("query");

if (query) {
    search(query);
}