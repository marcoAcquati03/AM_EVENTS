window.addEventListener('scroll', function() {
  const navbar = document.querySelector('.navbar');
  const scrolled = window.pageYOffset || document.documentElement.scrollTop;

  if (scrolled > 0) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

const slideshowContainer = document.querySelector('.slideshow-container');
const images = slideshowContainer.getElementsByTagName('img');
const prevButton = slideshowContainer.querySelector('.prev-button');
const nextButton = slideshowContainer.querySelector('.next-button');
const indicatorContainer = slideshowContainer.querySelector('.indicator-container');
const currentImageIndex = 0;

function showImage(index) {
for (let i = 0; i < images.length; i++) {
  images[i].classList.remove('active');
}
images[index].classList.add('active');

const indicators = indicatorContainer.getElementsByClassName('indicator');
for (let i = 0; i < indicators.length; i++) {
  indicators[i].classList.remove('active');
}
indicators[index].classList.add('active');
}

function slideImages(direction) {
if (direction === 'next') {
  currentImageIndex++;
  if (currentImageIndex >= images.length) {
    currentImageIndex = 0;
  }
} else if (direction === 'prev') {
  currentImageIndex--;
  if (currentImageIndex < 0) {
    currentImageIndex = images.length - 1;
  }
}
showImage(currentImageIndex);
}

prevButton.addEventListener('click', function () {
  slideImages('prev');
});

nextButton.addEventListener('click', function () {
  slideImages('next');
});

for (let i = 0; i < images.length; i++) {
const indicator = document.createElement('div');
indicator.classList.add('indicator');
indicatorContainer.appendChild(indicator);
}

const indicators = indicatorContainer.getElementsByClassName('indicator');
for (let i = 0; i < indicators.length; i++) {
indicators[i].addEventListener('click', function () {
  let index = Array.from(indicators).indexOf(this);
  slideImagesToIndex(index);
});
}

function slideImagesToIndex(index) {
  if (index === currentImageIndex) {
    return;
  }
  const direction = index > currentImageIndex ? 'next' : 'prev';
  currentImageIndex = index;
  showImage(currentImageIndex);
}

showImage(currentImageIndex);

setInterval(function () {
  slideImages('next');
}, 3000);
document.getElementById("myButton").addEventListener("click", function() {
  window.location.href = "login.html";
});

var map;
var userMarker;
var museumMarkers = []; 


function initMap() {

  navigator.geolocation.getCurrentPosition(function(position) {

    var lat = position.coords.latitude;
    var lng = position.coords.longitude;


    map = new google.maps.Map(document.getElementById('map'), {
            center: {lat: lat, lng: lng},
            zoom: 13,
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: false
        });


        var userIcon = {
            url: 'images/user.png',
            scaledSize: new google.maps.Size(40, 40)
        };


        userMarker = new google.maps.Marker({
            position: {lat: lat, lng: lng},
            map: map,
            icon: userIcon,
            title: 'La tua posizione'
        });


        var request = {
            location: {lat: lat, lng: lng},
            radius: 20000, 
            type: 'museum'
        };
        var service = new google.maps.places.PlacesService(map);
        service.nearbySearch(request, processResults);
    });
}


function processResults(results, status) {
    if (status !== google.maps.places.PlacesServiceStatus.OK) {
        console.error(status);
        return;
    }

    
    clearMuseumMarkers();

    
    var museumIcon = {
        url: 'images/museum.png',
        scaledSize: new google.maps.Size(40, 40)
    };


    for (var i = 0; i < results.length; i++) {
        createMuseumMarker(results[i], museumIcon);
    }
}


function createMuseumMarker(place, icon) {
    var marker = new google.maps.Marker({
        map: map,
        position: place.geometry.location,
        icon: icon,
        title: place.name
    });


    museumMarkers.push(marker);


    marker.addListener('click', function() {
        var service = new google.maps.places.PlacesService(map);
        service.getDetails({
            placeId: place.place_id
        }, function(result, status) {
            if (status === google.maps.places.PlacesServiceStatus.OK) {
                var infoWindow = new google.maps.InfoWindow({
                    content: '<h3>' + result.name + '</h3>' +
                        '<p>' + result.formatted_address + '</p>' +
                        '<p>Recensioni: ' + result.rating + '</p>'
                });
                infoWindow.open(map, marker);
            }
        });
    });
}


function clearMuseumMarkers() {
    for (let i = 0; i < museumMarkers.length; i++) {
        museumMarkers[i].setMap(null);
    }
    museumMarkers = [];
}


window.addEventListener('load', function() {
    initMap();
});



function redirectToMuseoPage(docId) {
  window.location.href = "museo.html?id=" + docId;
}

