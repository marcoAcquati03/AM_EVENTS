
        var eventiRef = db.collection("eventi");

        

        eventiRef.where("novita", "==", true).get().then(function(querySnapshot) {
            var eventContainer = document.getElementById("events-container");
            eventContainer.innerHTML = ""; 

            querySnapshot.forEach(function(doc) {
                var event = doc.data();
                var nomeEvento = event.Nome;
                var descrizioneEvento = event.Descrizione;
                var fotoEvento = event.foto;
                var luogoEvento = event.luogo;
                var prezzoEvento = event.prezzo;

                var nomeElement = document.createElement("h2");
                nomeElement.textContent = nomeEvento;
                eventContainer.appendChild(nomeElement);

                var descrizioneElement = document.createElement("p");
                descrizioneElement.textContent = descrizioneEvento;
                eventContainer.appendChild(descrizioneElement);

                var fotoElement = document.createElement("img");
                fotoElement.src = fotoEvento;
                eventContainer.appendChild(fotoElement);

                var luogoElement = document.createElement("p");
                luogoElement.textContent = luogoEvento;
                eventContainer.appendChild(luogoElement);

                var prezzoElement = document.createElement("p");
                prezzoElement.textContent = "Prezzo: " + prezzoEvento + " €";
                eventContainer.appendChild(prezzoElement);
            });
        }).catch(function(error) {
            console.log("Errore nel recuperare i documenti:", error);
        });



var categoriaButtons = document.getElementsByClassName("button-tipo");


for (var i = 0; i < categoriaButtons.length; i++) {
    categoriaButtons[i].addEventListener("click", function(event) {
        var categoria = event.target.dataset.categoria;
        filterResultsByCategoria(categoria);
    });
}


function filterResultsByCategoria(categoria) {
    if (categoria === "TUTTI") {
        eventiRef.get().then(function(querySnapshot) {
            var eventContainer = document.getElementById("events-container");
            eventContainer.innerHTML = "";

            querySnapshot.forEach(function(doc) {
                var event = doc.data();


                var nomeEvento = event.Nome;
                var descrizioneEvento = event.Descrizione;
                var fotoEvento = event.foto;
                var luogoEvento = event.luogo;
                var prezzoEvento = event.prezzo;


                var nomeElement = document.createElement("h2");
                nomeElement.textContent = nomeEvento;
                eventContainer.appendChild(nomeElement);

                var descrizioneElement = document.createElement("p");
                descrizioneElement.textContent = descrizioneEvento;
                eventContainer.appendChild(descrizioneElement);

                var fotoElement = document.createElement("img");
                fotoElement.src = fotoEvento;
                eventContainer.appendChild(fotoElement);

                var luogoElement = document.createElement("p");
                luogoElement.textContent = luogoEvento;
                eventContainer.appendChild(luogoElement);

                var prezzoElement = document.createElement("p");
                prezzoElement.textContent = "Prezzo: " + prezzoEvento + " €";
                eventContainer.appendChild(prezzoElement);
            });
        }).catch(function(error) {
            console.log("Errore nel recuperare i documenti:", error);
        });
    } else {
        eventiRef.where("categoria", "==", categoria)
            .get()
            .then(function(querySnapshot) {
                var eventContainer = document.getElementById("events-container");
                eventContainer.innerHTML = "";

                querySnapshot.forEach(function(doc) {
                    var event = doc.data();


                    var nomeEvento = event.Nome;
                    var descrizioneEvento = event.Descrizione;
                    var fotoEvento = event.foto;
                    var luogoEvento = event.luogo;
                    var prezzoEvento = event.prezzo;


                    var nomeElement = document.createElement("h2");
                    nomeElement.textContent = nomeEvento;
                    eventContainer.appendChild(nomeElement);

                    var descrizioneElement = document.createElement("p");
                    descrizioneElement.textContent = descrizioneEvento;
                    eventContainer.appendChild(descrizioneElement);

                    var fotoElement = document.createElement("img");
                    fotoElement.src = fotoEvento;
                    eventContainer.appendChild(fotoElement);

                    var luogoElement = document.createElement("p");
                    luogoElement.textContent = luogoEvento;
                    eventContainer.appendChild(luogoElement);

                    var prezzoElement = document.createElement("p");
                    prezzoElement.textContent = "Prezzo: " + prezzoEvento + " €";
                    eventContainer.appendChild(prezzoElement);
                });
            })
            .catch(function(error) {
                console.log("Errore nel recuperare i documenti:", error);
            });
    }
}