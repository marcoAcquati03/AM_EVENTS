const auth = firebase.auth();
const loginForm = document.querySelector(".form-login form");
        loginForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const email = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            signInWithEmailAndPassword(email, password);
        });

        function signInWithEmailAndPassword(email, password) {
            auth.signInWithEmailAndPassword(email, password)
                .then(function(userCredential) {
                    const user = userCredential.user;
                    console.log("Accesso effettuato per l'utente:", user.email);
                    window.location.href = "dashboard.html";
                })
                .catch(function(error) {
                    const errorCode = error.code;
                    const errorMessage = error.message;
                    console.log("Errore durante l'accesso:", errorCode, errorMessage);
                    const errorDiv = document.getElementById("login-error");
                    switch (errorCode) {
                        case "auth/invalid-email":
                            errorDiv.textContent = "L'email non è nel formato corretto";
                            break;
                        case "auth/user-not-found":
                            errorDiv.textContent = "L'email è errata";
                            break;
                        case "auth/wrong-password":
                            errorDiv.textContent = "La password è errata";
                            break;
                        default:
                            errorDiv.textContent = "Errore durante l'accesso: " + errorMessage;
                            break;
                    }
                });
        }