
const firebaseConfig = {
    apiKey: "AIzaSyDSKckdRUCJYsq9reUjTNa8vgNMHEIXdn8",
    authDomain: "pw01-d3c8f.firebaseapp.com",
    databaseURL: "https://pw01-d3c8f-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "pw01-d3c8f",
    storageBucket: "pw01-d3c8f.appspot.com",
    messagingSenderId: "552358930869",
    appId: "1:552358930869:web:a6d9949cec8c1509e791fc"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();