
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    const regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}


function getMuseoDetails(museoId) {
    
    db.collection("eventi")
        .doc(museoId)
        .get()
        .then(function (doc) {
            if (doc.exists) {
                const nomeElement = document.createElement("h3");
                nomeElement.id = "nome";

                const descrizioneElement = document.createElement("p");
                descrizioneElement.id = "descrizione";

                const prezzoElement = document.createElement("p");
                prezzoElement.id = "prezzo";

                const fotoElement = document.createElement("img");
                fotoElement.id = "foto";

                const luogoElement = document.createElement("p");
                luogoElement.id = "luogo";


                nomeElement.textContent = doc.data().Nome;
                descrizioneElement.textContent = doc.data().Descrizione;
                prezzoElement.textContent = "Prezzo: " + doc.data().prezzo + " €";
                fotoElement.src = doc.data().foto;
                luogoElement.textContent = doc.data().luogo;


                const museoDetailsDiv = document.getElementById("museoDetails");
                museoDetailsDiv.appendChild(nomeElement);
                museoDetailsDiv.appendChild(descrizioneElement);
                museoDetailsDiv.appendChild(prezzoElement);
                museoDetailsDiv.appendChild(fotoElement);
                museoDetailsDiv.appendChild(luogoElement);
            } else {
                console.log("Il documento non esiste");
            }
        })
        .catch(function (error) {
            console.log("Error getting document: ", error);
        });
}



var museoId = getParameterByName("id");

if (museoId) {
    getMuseoDetails(museoId);
}
