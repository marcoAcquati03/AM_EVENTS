firebase.auth().onAuthStateChanged(function(user) {
  if (!user) {
    const carrelloItems = document.getElementById("carrelloItems");
    const emptyCartMessage = document.createElement("div");
    emptyCartMessage.className = "biglietti";
    emptyCartMessage.innerHTML = `
      <h2>NON HAI ACQUISTATO NESSUN BIGLIETTO!</h2>
      <p>Naviga nel nostro sito alla ricerca del museo più adatto alle tue esigenze!</p>
    `;
    carrelloItems.appendChild(emptyCartMessage);
  } else {
    const carrelloRef = db.collection("carrello");
    const carrelloItems = document.getElementById("carrelloItems");
    carrelloRef.get().then((querySnapshot) => {
      if (querySnapshot.empty) {
        const emptyCartMessage = document.createElement("div");
        emptyCartMessage.className = "biglietti";
        emptyCartMessage.innerHTML = `
          <h2>NON HAI ACQUISTATO NESSUN BIGLIETTO!</h2>
          <p>Naviga nel nostro sito alla ricerca del museo più adatto alle tue esigenze!</p>
        `;
        carrelloItems.appendChild(emptyCartMessage);
      } else {
        querySnapshot.forEach((doc) => {
          const nome = doc.data().nome;
          const foto = doc.data().foto;
          const luogo = doc.data().luogo;
          const prezzo = doc.data().prezzo;
          const quantity = doc.data().quantity;
          const item = document.createElement("div");
          item.innerHTML = `
            <img src="${foto}" alt="${nome}">
            <h3>${nome}</h3>
            <p>Luogo: ${luogo}</p>
            <p>${prezzo}</p>
            <p>Numero biglietti: ${quantity}</p>
          `;
          carrelloItems.appendChild(item);
        });
      }
    }).catch((error) => {
      console.log("Errore nel recupero dei dati dal carrello:", error);
    });
  }
});
