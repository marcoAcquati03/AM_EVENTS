document.getElementById("recuperaPass").addEventListener("click", function() {
    const email = prompt("Inserisci l'indirizzo email associato al tuo account:");
  
    if (email !== null) {
      firebase.auth().sendPasswordResetEmail(email)
        .then(function() {
          console.log("Email di reset della password inviata con successo!");
        })
        .catch(function(error) {
          console.log("Si è verificato un errore durante l'invio dell'email di reset della password:", error);
        });
    }
});
  